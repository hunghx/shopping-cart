create
    definer = root@localhost procedure PROC_DeleteOrderDetail(IN orderDetailId int)
begin
    delete  from OrderDetail where id = orderDetailId;
end;

