create
    definer = root@localhost procedure PROC_GETALL()
begin
    select * from Student;
end;

