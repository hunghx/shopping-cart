create
    definer = root@localhost procedure PROC_SEARCHBYNAME(IN nameSearch varchar(255))
begin
    select * from Student where name like concat('%',nameSearch,'%');
end;

