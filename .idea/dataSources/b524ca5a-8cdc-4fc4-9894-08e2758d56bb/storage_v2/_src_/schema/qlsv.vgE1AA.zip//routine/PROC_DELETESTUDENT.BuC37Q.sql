create
    definer = root@localhost procedure PROC_DELETESTUDENT(IN idDel int)
begin
    delete  from  Student where  id =idDel;
end;

