create
    definer = root@localhost procedure PROC_CreateNewOrder(IN userId int, IN totalP float, IN addressP varchar(255),
                                                           IN phoneP varchar(11))
begin
    insert into Orders(user_id,total,address,phone) values (userId,totalP,addressP,phoneP);
end;

