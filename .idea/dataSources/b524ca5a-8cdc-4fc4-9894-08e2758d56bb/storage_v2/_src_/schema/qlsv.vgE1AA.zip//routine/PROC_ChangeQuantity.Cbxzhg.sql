create
    definer = root@localhost procedure PROC_ChangeQuantity(IN orderId int, IN productId int, IN quantityUp int)
begin
    update OrderDetail set quantity=quantityUp where order_id= orderId and product_id=productId;
end;

