create
    definer = root@localhost procedure PROC_FINDBYUSERNAME(IN user varchar(255))
begin
    select * from Accounts where username like user;
end;

